from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask('Visited Cities')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cities.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class VisitedCity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    city = db.Column(db.String(100), nullable=False)
    visit_date = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f'City {self.id}: {self.city} visited on {self.visit_date}'

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        city = request.form['city']
        visit_date = request.form['visit_date']
        new_city = VisitedCity(city=city, visit_date=visit_date)
        db.session.add(new_city)
        db.session.commit()
        return redirect(url_for('index'))
    
    cities = VisitedCity.query.all()
    return render_template('index.html', cities=cities)

@app.route('/clear', methods=['POST'])
def clear():
    db.session.query(VisitedCity).delete()
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)